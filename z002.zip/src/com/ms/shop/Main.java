package com.ms.shop;

public class Main {
	public static void main(String[] args) {
		
		Shop s = new Shop();
		s.proc();
		
		
	}
}
